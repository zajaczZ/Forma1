﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace F1
{
    class Forma1
    {
        public string nev;
        public DateTime szulev;
        public string nemzet;
        public int rajt;

        public Forma1(string sor)
        {
            string[] temp = sor.Split(';');
            nev = temp[0];
            szulev = Convert.ToDateTime(temp[1]);
            nemzet = temp[2];
            if (!string.IsNullOrEmpty(temp[3]))
            {
                rajt = int.Parse(temp[3]);
            }

        }
    }
    internal class Program
    {
    static List<Forma1> lista = new List<Forma1>();
    static void beolvas()
    {
            StreamReader sr = new StreamReader("pilotak.csv",Encoding.Default);
            sr.ReadLine();
            while (!sr.EndOfStream)
            {
                Forma1 uj = new Forma1(sr.ReadLine());
                lista.Add(uj);
                

            }
            sr.Close();

            
    }

        static void f3()
        {
            Console.WriteLine("3.feladat");
            Console.WriteLine($"{lista.Count()}");
        }
        static void f4()
        {
            Console.WriteLine("4.feladat");
            Console.WriteLine($"{lista.Select(x=>x.nev).Last()}");
        }
        static void f5()
        {
            Console.WriteLine("5.feladat");
            foreach (var item in lista)
            {
                if (item.szulev.Year<1900 && item.szulev.Year>1799)
                {
                    Console.WriteLine($"{item.nev} ({item.szulev.Year}. {item.szulev.Month}. {item.szulev.Day}.)");

                }

            }
        }
        static void f6()
        {
            Console.WriteLine("6.feladat");
            Console.WriteLine($"{lista.FindAll(x => x.rajt > 0).OrderBy(x => x.rajt).First().nemzet}");

        }
        static void f7()
        {
            Console.WriteLine("7.feladat");
            Dictionary<int, int> stat = new Dictionary<int, int>();

            foreach (var item in lista)
            {
                int kulcs = item.rajt;
                if (!stat.ContainsKey(kulcs))
                {
                    stat.Add(kulcs, 0);
                }
                stat[kulcs]++; 
            }
            
            foreach (var item in stat)
            {
                if (item.Value>1 && item.Key!=0)
                {
                    Console.Write($"{item.Key}, ");

                }               
                
            }
        }
        static void Main(string[] args)
        {
            beolvas();
            f3();
            f4();
            f5();
            f6();
            f7();



            Console.ReadKey();
        }
    }
}
